# backend-nodejs-mongodb

## Para ejecutar MongoDB en MacOS o Linux:

```sh
./bin/mongod --dbpath ./data
```