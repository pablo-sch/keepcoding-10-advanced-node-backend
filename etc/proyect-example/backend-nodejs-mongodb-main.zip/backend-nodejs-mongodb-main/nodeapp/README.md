# NodeApp

## Installation

Install dependencies with:

```sh
npm install
```

On first deploy you can use the next command to initialize the database:

```sh
npm run initDB
```