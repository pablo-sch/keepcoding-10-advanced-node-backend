'use strict';

// una función que devuelve una promesa
function sleep(ms) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(42)
    }, ms)
  })
}

const promesa = sleep(2000)

const result = await sleep(2000)

promesa.then((result) => {
  console.log('ha pasado un segundo con resultado:', result)
  // return sleep(2000)
  // throw new Error('fatallll!!!!')
  return result + 20
}).catch(err => {
  console.log('gestiono el error del primer sleep')
}).then((result) => {
  console.log('sigo con:', result)
  return sleep(2000)
}).then(() => {
  console.log('sigo mas')
  return sleep(2000)
}).catch(err => {
  console.error('Hubo un error', err.message)
})