'use strict';

const EventEmitter = require('node:events')

const emitter = new EventEmitter()

emitter.on('llamada de teléfono', (payload) => {
  if (payload.llamante === 'hermana') {
    return
  }
  console.log('ring ring')
})

emitter.once('llamada de teléfono', () => {
  console.log('brr brr')
})

emitter.emit('llamada de teléfono', { llamante: 'hermana'})
emitter.emit('llamada de teléfono', { llamante: 'hermana'})
emitter.emit('llamada de teléfono', { llamante: 'hermana'})