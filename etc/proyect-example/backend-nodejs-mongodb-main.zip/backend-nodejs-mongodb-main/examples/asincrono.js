'use strict';

function escribeTrasDosSegundos(texto, callback) {
  setTimeout(function() {
    console.log(texto)
    callback()
  }, 2000)
}

// queremos hacer un bucle con callbacks
function serie(n, funcionQueQueremosEjecutar, callbackFinal) {
  if (n === 0) {
    // he terminado
    callbackFinal()
    return
  }
  n = n - 1
  funcionQueQueremosEjecutar('texto' + n, function() {
    serie(n, funcionQueQueremosEjecutar, callbackFinal)
  })
}

serie(5, escribeTrasDosSegundos, function() {
  console.log('fin')
})


// escribeTrasDosSegundos('texto1', function() {
//   escribeTrasDosSegundos('texto2', function() {
//     console.log('fin')
//   })
// })
