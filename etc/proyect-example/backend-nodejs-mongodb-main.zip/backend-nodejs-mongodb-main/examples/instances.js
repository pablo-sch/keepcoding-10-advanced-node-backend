'use strict';

// crear una función para usarla como un constructor de objetos
function Fruta(nombre) {
  this.nombre = nombre
  // this.saluda = function() { console.log('Hola, soy', this.nombre )}
  this.saluda = () => { console.log('Hola, soy', this.nombre )}
}

const limon = new Fruta('limon')

// javascript pra determinar cual es el contenido de "this" en un método,
// busca el primer punto a la izquierda de los paréntesis de ejecución
// y lo que hay a la izquierda de ese punto, es el "this"
// limon.saluda()

setTimeout(limon.saluda, 2000)
// setTimeout(limon.saluda.bind(limon), 2000)

// const miFuncion = limon.saluda.bind(limon)
// miFuncion()