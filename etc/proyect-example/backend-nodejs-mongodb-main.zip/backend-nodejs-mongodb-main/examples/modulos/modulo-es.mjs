// modulo de tipo EcmaScript (ES module)
export default {
  suma(a, b) { return a + b},
  texto: ''
}

export const texto3 = 'sopy texto3'